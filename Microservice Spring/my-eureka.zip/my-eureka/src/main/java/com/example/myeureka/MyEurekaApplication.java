package com.example.myeureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEurekaApplication.class, args);
	}
}
