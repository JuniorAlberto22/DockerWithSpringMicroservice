package com.example.mycustomer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyCustomerApplication.class, args);
	}
}
