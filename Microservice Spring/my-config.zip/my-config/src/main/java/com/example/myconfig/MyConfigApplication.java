package com.example.myconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyConfigApplication.class, args);
	}
}
