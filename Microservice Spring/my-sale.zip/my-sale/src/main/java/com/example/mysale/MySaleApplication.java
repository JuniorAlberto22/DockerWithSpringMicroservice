package com.example.mysale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySaleApplication.class, args);
	}
}
