package com.example.myregister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyRegisterApplication.class, args);
	}
}
